 <?php 
$link = mysql_connect('db.mysql.com', 'db_username', 'db_password'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(page_title); 
?> 