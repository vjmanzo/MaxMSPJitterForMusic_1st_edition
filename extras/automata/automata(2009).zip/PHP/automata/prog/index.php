<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<div align="left">
<?php
//opens php code
include 'connect.php';
$ID=$_GET['ID'];
$titlepage=$_POST['title']; //retrieves data from the submitted text box called title
if(isset($ID))
{
$titlepage=$ID;
$titlepage= ereg_replace("[^0-9]", "", $titlepage); 
}
if(isset($titlepage))
{
if($titlepage!='')
{
$updater="Update current_title set current='$titlepage' where ID='1'";
mysql_query($updater) or die("Did not update");
}
}
$titlestats="Select * from current_title where ID='1'";
$titlestats2=mysql_query($titlestats);
$titlestats3=mysql_fetch_array($titlestats2);
$titlepage=$titlestats3[current];
print "<center><form method='post' action='index.php'>"; //opens form and center
print "<input type='text' name='title' value='$titlepage'>"; //creates text box called title and loads whatever was previously submitted
print "<br><input type='submit' name='submit' value='Change'>"; //creates submit button called submit that is labeled "Change"
print "</form></center>";//closes form and center
if(isset($ID))
echo "<script>document.location.href='http://vjmanzo.com/clients/automata/src/right_main.php?PG_SHOWALL=0&sort=0&startMessage=1&mailbox=INBOX'</script>";



print "<title>$titlepage</title>"; //prints the data from the submitted text box as the title of the page

 

//closes php code
?>
</div>
</body>
</html>
