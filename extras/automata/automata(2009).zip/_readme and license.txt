automata (c) 2009 
created by V.J. Manzo | www.vjmanzo.com/cv
 and Dan Manzo | www.knockoutmedia.com
 
all rights reserved. 





************************

 

By using this work you are agreeing to our license agreement:



License Agreement
Creative Commons 
Attribution-Noncommercial-Share Alike 3.0 Unported

http://creativecommons.org/licenses/by-nc-sa/3.0/




************************




to modify this work, read the "files to change" document in each folder.




for more information vist:

www.vjmanzo.com/automata

___  __ |__| _____ _____    ____ ____________  
\  \/ / |  |/     \\__  \  /    \\___   /  _ \ 
 \   /  |  |  Y Y  \/ __ \|   |  \/    (  <_> )
  \_/\__|  |__|_|  (____  /___|  /_____ \____/ 
    \______|     \/     \/     \/      \/      

    .___      __                                  .__                .__     
  __| _/_____/  |_    ____  ____   _____     _____|  | _____    _____|  |__  
 / __ |/  _ \   __\ _/ ___\/  _ \ /     \   /  ___/  | \__  \  /  ___/  |  \ 
/ /_/ (  <_> )  |   \  \__(  <_> )  Y Y  \  \___ \|  |__/ __ \_\___ \|   Y  \
\____ |\____/|__|    \___  >____/|__|_|  / /____  >____(____  /____  >___|  /
     \/                  \/            \/       \/          \/     \/     \/ 

               __                         __          
_____   __ ___/  |_  ____   _____ _____ _/  |______   
\__  \ |  |  \   __\/  _ \ /     \\__  \\   __\__  \  
 / __ \|  |  /|  | (  <_> )  Y Y  \/ __ \|  |  / __ \_
(____  /____/ |__|  \____/|__|_|  (____  /__| (____  /
     \/                         \/     \/          \/ 